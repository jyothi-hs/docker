package com.mindtree.BankAccount.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.BankAccount.dao.AccountDao;
import com.mindtree.BankAccount.dao.BankDao;
import com.mindtree.BankAccount.entity.Account;
import com.mindtree.BankAccount.entity.Bank;
import com.mindtree.BankAccount.exception.AccountNotFoundException;
import com.mindtree.BankAccount.exception.AppServiceException;
import com.mindtree.BankAccount.exception.InsufficientFundException;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	BankDao bdao;

	@Autowired
	AccountDao dao;

	public void redirect(int id, int money, int type) throws AppServiceException {

		if (type == 1)
			add(id, money);
		else
			withdraw(id, money);

	}

	public void withdraw(int acc_no, int amount) throws AppServiceException {
		Optional<Account> acc = dao.findById(acc_no);
		Account ac = acc.get();
		if (ac.getBalance() < amount)
			throw new InsufficientFundException("Your balance is very low");
		ac.setBalance(ac.getBalance() - amount);
		dao.save(ac);

	}
	/*public List<Account> myJpqlQuery()
	{
		
		return dao.getAllThings();
	}*/
	public void addAccount(String uname, int type, int bankid) {
		Account acc = new Account();
		acc.setUsername(uname);
		acc.setBalance(0);
		if (type == 1)
			acc.setGender("male");
		else
			acc.setGender("female");

		Optional<Bank> b = bdao.findById(bankid);
		acc.setBank(b.get());

		dao.save(acc);

	}

	public void add(int acc_no, int amount) throws AppServiceException {
		Optional<Account> acc = dao.findById(acc_no);

		acc.orElseThrow(() -> new AccountNotFoundException("Invalid Account Info"));

		Account ac = acc.get();
		ac.setBalance(ac.getBalance() + amount);
		dao.save(ac);

	}

	public Account findBalance(int id) throws AppServiceException {
		Optional<Account> acc = dao.findById(id);
		acc.orElseThrow(() -> new AccountNotFoundException("Invalid Account Info"));
		return acc.get();
	}

}
