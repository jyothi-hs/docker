package com.mindtree.BankAccount.service;

import java.util.List;

import com.mindtree.BankAccount.entity.Bank;

public interface BankService {

	public List<Bank> getAllBanks();
}
