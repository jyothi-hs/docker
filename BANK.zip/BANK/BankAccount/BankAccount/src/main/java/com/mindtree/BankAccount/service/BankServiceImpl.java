package com.mindtree.BankAccount.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.BankAccount.dao.BankDao;
import com.mindtree.BankAccount.entity.Bank;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankDao dao;

	public List<Bank> getAllBanks() {

		return dao.findAll();

	}

}
