package com.mindtree.BankAccount.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Account {

	@GeneratedValue
	@Id
	int acc_no;
	String username;
	int balance;
	String gender;

	@ManyToOne
	Bank bank;

	public int getAcc_no() {
		return acc_no;
	}

	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(int acc_no, String username, int balance, String gender, Bank bank) {
		super();
		this.acc_no = acc_no;
		this.username = username;
		this.balance = balance;
		this.gender = gender;
		this.bank = bank;
	}

}
