package com.mindtree.BankAccount.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Bank {

	
	@Id
	int bid;
	int bcode;
	String name;
	
	
	@OneToMany(mappedBy="bank",cascade = CascadeType.ALL)
	List<Account> acc;


	public Bank(int bid, int bcode, String name, List<Account> acc) {
		super();
		this.bid = bid;
		this.bcode = bcode;
		this.name = name;
		this.acc = acc;
	}


	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getBid() {
		return bid;
	}


	public void setBid(int bid) {
		this.bid = bid;
	}


	public int getBcode() {
		return bcode;
	}


	public void setBcode(int bcode) {
		this.bcode = bcode;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public List<Account> getAcc() {
		return acc;
	}


	public void setAcc(List<Account> acc) {
		this.acc = acc;
	}
	
}
