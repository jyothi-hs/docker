package com.mindtree.BankAccount.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.BankAccount.entity.Account;

@Repository
public interface AccountDao extends JpaRepository<Account,Integer>{
//	@Query("select * from account")
//	public List<Account> getAllThings();
	
}
