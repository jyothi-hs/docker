package com.mindtree.BankAccount.service;

import java.util.List;

import com.mindtree.BankAccount.entity.Account;
import com.mindtree.BankAccount.exception.AppServiceException;

public interface AccountService {
	public void redirect(int id, int money, int type) throws AppServiceException;

	public void withdraw(int acc_no, int amount) throws AppServiceException;

	public void add(int acc_no, int amount) throws AppServiceException;

	public Account findBalance(int id) throws AppServiceException;

	public void addAccount(String uname, int type, int bankid);
	
	public List<Account> myJpqlQuery();
}
