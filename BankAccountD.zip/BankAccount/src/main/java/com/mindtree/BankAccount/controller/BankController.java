package com.mindtree.BankAccount.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.BankAccount.entity.Account;
import com.mindtree.BankAccount.exception.AppServiceException;
import com.mindtree.BankAccount.service.AccountService;
import com.mindtree.BankAccount.service.BankService;

@Controller
public class BankController {

	@Autowired
	AccountService as;

	@Autowired
	BankService bs;

	@RequestMapping("/")
	public String home() {
//		List<Account> acc = as.myJpqlQuery();
		return "home";
	}

	@RequestMapping("/account")
	public String account(ModelMap map) {
		map.put("bank", bs.getAllBanks());
		return "account";
	}

	@PostMapping("/addaccount")
	public String addAccount(ModelMap map, @RequestParam String uname, @RequestParam int type,
	    @RequestParam int banks) {

		as.addAccount(uname, type, banks);
		map.put("bank", bs.getAllBanks());
		return "account";
	}

	@PostMapping("/trans")
	public String transaction(ModelMap map, @RequestParam int id, @RequestParam int type, @RequestParam int money) {

		try {
			as.redirect(id, money, type);
		} catch (AppServiceException e) {
			map.put("msg", e.getMessage());
			return "error";
		}
		return "home";

	}

	@RequestMapping("/balance")
	public String balance() {
		return "balance";
	}

	@GetMapping("/find/{id}")
	public String balance(ModelMap map, @PathVariable int id) {
		try {
			Account acc = as.findBalance(id);
			map.put("a", acc.getAcc_no());
			map.put("b", acc.getUsername());

			map.put("c", acc.getBank().getName());

			map.put("d", acc.getBalance());
		} catch (AppServiceException e) {
			map.put("msg", e.getMessage());
			return "error";
		}
		return "balance";
	}

}
